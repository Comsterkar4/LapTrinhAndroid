package com.example.appbtl.admin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.appbtl.R;

public class GiaoDienAdmin extends AppCompatActivity {

    private Button btnManageTruyen, btnManageChap, btnManageNguoiDung , btnAddGenre , btnManageBinhLuan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_home);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Trang chủ Admin");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo các nút
        btnAddGenre = findViewById(R.id.btnAddGenre);
        btnManageTruyen = findViewById(R.id.btnManageTruyen);
        btnManageChap = findViewById(R.id.btnManageChap); // Sửa: Gán đúng btnManageChap
        btnManageNguoiDung = findViewById(R.id.btnManageNguoiDung);
        btnManageBinhLuan = findViewById(R.id.btnManageBinhLuan);


        btnAddGenre.setOnClickListener(v -> {
            Intent intent = new Intent(GiaoDienAdmin.this, AdminTheLoai.class);
            startActivity(intent);
        });

        // Xử lý sự kiện nhấn nút Quản lý truyện
        btnManageTruyen.setOnClickListener(v -> {
            Intent intent = new Intent(GiaoDienAdmin.this, AdminActivity.class);
            startActivity(intent);
        });

        // Xử lý sự kiện nhấn nút Quản lý chương
        btnManageChap.setOnClickListener(v -> {
            // Giả định bạn có một Activity để quản lý chương, thay AdminChapActivity bằng tên thực tế
            Intent intent = new Intent(GiaoDienAdmin.this, AdminChap.class);
            startActivity(intent);
        });

        // Xử lý sự kiện nhấn nút Quản lý người dùng
        btnManageNguoiDung.setOnClickListener(v -> {
            Intent intent = new Intent(GiaoDienAdmin.this, AdminNguoiDung.class);
            startActivity(intent);
        });
        // xử lý ấn bin luân
        btnManageBinhLuan.setOnClickListener(v -> {
            // Giả định bạn có một Activity để quản lý chương, thay AdminChapActivity bằng tên thực tế
            Intent intent = new Intent(GiaoDienAdmin.this, AdminBinhLuan.class);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // Đóng activity khi nhấn nút quay lại
        return true;
    }
}