package com.example.appbtl.tinhnang;

import java.io.Serializable;
import java.util.List;

public class Chapter implements Serializable {
    private String chapterNumber;
    private List<String> content; // Danh sách URI ảnh

    public Chapter(String chapterNumber, List<String> content) {
        this.chapterNumber = chapterNumber;
        this.content = content;
    }

    public String getChapterNumber() {
        return chapterNumber;
    }

    public List<String> getContent() {
        return content;
    }
}