package com.example.appbtl.model;

import java.io.Serializable;
import java.util.Date;

public class Truyen implements Serializable {
    int id;
    String ten;
    String tac_gia;
    String mo_ta;
    String anh_bia;
    int id_the_loai;
    int id_trang_thai;
    int luot_xem;
    int luot_thich;
    String ngay_tao;

    public Truyen(int id, String ten, String tac_gia, String mo_ta, String anh_bia, int id_the_loai, int id_trang_thai, int luot_xem, int luot_thich, String ngay_tao) {
        this.id = id;
        this.ten = ten;
        this.tac_gia = tac_gia;
        this.mo_ta = mo_ta;
        this.anh_bia = anh_bia;
        this.id_the_loai = id_the_loai;
        this.id_trang_thai = id_trang_thai;
        this.luot_xem = luot_xem;
        this.luot_thich = luot_thich;
        this.ngay_tao = ngay_tao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getTac_gia() {
        return tac_gia;
    }

    public void setTac_gia(String tac_gia) {
        this.tac_gia = tac_gia;
    }

    public String getMo_ta() {
        return mo_ta;
    }

    public void setMo_ta(String mo_ta) {
        this.mo_ta = mo_ta;
    }

    public String getAnh_bia() {
        return anh_bia;
    }

    public void setAnh_bia(String anh_bia) {
        this.anh_bia = anh_bia;
    }

    public int getId_the_loai() {
        return id_the_loai;
    }

    public void setId_the_loai(int id_the_loai) {
        this.id_the_loai = id_the_loai;
    }

    public int getId_trang_thai() {
        return id_trang_thai;
    }

    public void setId_trang_thai(int id_trang_thai) {
        this.id_trang_thai = id_trang_thai;
    }

    public int getLuot_xem() {
        return luot_xem;
    }

    public void setLuot_xem(int luot_xem) {
        this.luot_xem = luot_xem;
    }

    public int getLuot_thich() {
        return luot_thich;
    }

    public void setLuot_thich(int luot_thich) {
        this.luot_thich = luot_thich;
    }

    public String getNgay_tao() {
        return ngay_tao;
    }

    public void setNgay_tao(String ngay_tao) {
        this.ngay_tao = ngay_tao;
    }
}