package com.example.appbtl.tinhnang;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import java.util.List;

public class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.ChapterViewHolder> {

    private List<Chapter> chapterList;
    private OnChapterLongClickListener listener;

    // Constructor chỉ cần List<Chapter> (listener là tùy chọn)
    public ChapterAdapter(List<Chapter> chapterList) {
        this(chapterList, null);
    }

    public ChapterAdapter(List<Chapter> chapterList, OnChapterLongClickListener listener) {
        this.chapterList = chapterList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ChapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chapter, parent, false);
        return new ChapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {
        Chapter chapter = chapterList.get(position);
        holder.chapterNumber.setText(chapter.getChapterNumber());
        if (listener != null) {
            holder.itemView.setOnLongClickListener(v -> {
                listener.onChapterLongClick(position);
                return true;
            });
        } else {
            holder.itemView.setOnLongClickListener(null);
        }
    }

    @Override
    public int getItemCount() {
        return chapterList.size();
    }

    public static class ChapterViewHolder extends RecyclerView.ViewHolder {
        TextView chapterNumber;

        public ChapterViewHolder(@NonNull View itemView) {
            super(itemView);
            chapterNumber = itemView.findViewById(R.id.chapterNumber);
        }
    }

    public interface OnChapterLongClickListener {
        void onChapterLongClick(int position);
    }
}