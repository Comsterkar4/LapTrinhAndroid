package com.example.appbtl;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ProfileActivity extends AppCompatActivity {

    // Khai báo các thành phần giao diện
    private ImageView userAvatar;
    private TextView userName;
    private TextView userEmail;
    private TextView userPhone;
    private TextView userAddress;
    private TextView userBio;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thong_tin_nguoi_dung);

        // Ánh xạ các thành phần giao diện
        toolbar = findViewById(R.id.toolbar);
        userAvatar = findViewById(R.id.userAvatar);
        userName = findViewById(R.id.userName);
        userEmail = findViewById(R.id.userEmail);
        userPhone = findViewById(R.id.userPhone);
        userAddress = findViewById(R.id.userAddress);
        userBio = findViewById(R.id.userBio);

        // Thiết lập Toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Hồ sơ người dùng");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Nút quay lại
        }

        // Gán dữ liệu giả (fake data)
        userName.setText("Họ và tên: Trần Thị Bích Ngọc");
        userEmail.setText("Email: bichngoc.tran@example.com");
        userPhone.setText("Số điện thoại: 0987 654 321");
        userAddress.setText("Địa chỉ: 456 Nguyễn Trãi, TP. Hồ Chí Minh");
        userBio.setText("Giới thiệu: Tôi là một nhà thiết kế đồ họa, đam mê sáng tạo và nghệ thuật.");

        // Gán ảnh đại diện (nếu có ảnh trong drawable, ví dụ: avatar.jpg)
        // userAvatar.setImageResource(R.drawable.avatar);
        // Tạm thời để ảnh placeholder từ XML (darker_gray)
    }

    // Xử lý sự kiện nút quay lại trên Toolbar
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}