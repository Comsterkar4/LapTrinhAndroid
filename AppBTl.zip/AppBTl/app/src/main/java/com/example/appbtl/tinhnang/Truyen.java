package com.example.appbtl.tinhnang;

import java.io.Serializable;
import java.util.List;

public class Truyen implements Serializable {
    private int id;
    private String title;
    private String imageUrl;
    private String description;
    private String author;
    private List<String> genres; // Thay String genre thành List<String> genres
    private List<Chapter> chapters;

    public Truyen(int id, String title, String imageUrl, String description, String author, List<String> genres, List<Chapter> chapters) {
        this.id = id;
        this.title = title;
        this.imageUrl = imageUrl;
        this.description = description;
        this.author = author;
        this.genres = genres;
        this.chapters = chapters;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public String getAuthor() {
        return author;
    }

    public List<String> getGenres() {
        return genres;
    }

    public List<Chapter> getChapters() {
        return chapters;
    }
}