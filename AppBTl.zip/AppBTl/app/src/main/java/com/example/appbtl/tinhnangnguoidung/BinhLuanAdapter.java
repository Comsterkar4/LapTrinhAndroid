package com.example.appbtl.tinhnangnguoidung;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import java.util.List;

public class BinhLuanAdapter extends RecyclerView.Adapter<BinhLuanAdapter.BinhLuanViewHolder> {

    private List<BinhLuan> commentList;

    public BinhLuanAdapter(List<BinhLuan> commentList) {
        this.commentList = commentList;
    }

    @Override
    public BinhLuanViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_comment, parent, false);
        return new BinhLuanViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BinhLuanViewHolder holder, int position) {
        BinhLuan binhLuan = commentList.get(position);
        holder.name.setText(binhLuan.getName());
        holder.content.setText(binhLuan.getContent());
    }

    @Override
    public int getItemCount() {
        return commentList != null ? commentList.size() : 0;
    }

    public static class BinhLuanViewHolder extends RecyclerView.ViewHolder {
        TextView name, content;

        public BinhLuanViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.userName);
            content = itemView.findViewById(R.id.commentContent);
        }
    }
}