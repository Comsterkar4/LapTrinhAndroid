package com.example.appbtl;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.appbtl.adapter.TruyenAdapter;
import com.example.appbtl.model.Truyen;
import com.example.appbtl.model.TruyenModel;
import com.example.appbtl.retrofit.ApiDocTruyen;
import com.example.appbtl.retrofit.RetrofitClient;
import com.example.appbtl.utils.Utils;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.List;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class TrangChuActivity extends AppCompatActivity implements TruyenAdapter.OnTruyenClickListener {

    private DrawerLayout drawerLayout;
    private RecyclerView recyclerViewTruyen;
    private ViewFlipper bannerFlipper;
    private TruyenAdapter truyenAdapter;
    CompositeDisposable compositeDisposable = new CompositeDisposable();
    ApiDocTruyen apiDocTruyen;
    List<Truyen> mangTruyen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        apiDocTruyen = RetrofitClient.getInstance(Utils.BASE_URL).create(ApiDocTruyen.class);
        AnhXa();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setCheckedItem(R.id.nav_home);

        navigationView.setNavigationItemSelectedListener(menuItem -> {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.nav_home) {
                // Đã ở Trang chủ
            } else if (itemId == R.id.nav_favorite) {
                startActivity(new Intent(this, YeuThichActivity.class));
            } else if (itemId == R.id.nav_theloai) {
                startActivity(new Intent(this, TheLoaiActivity.class));
            } else if (itemId == R.id.nav_history) {
                startActivity(new Intent(this, LichSuActivity.class));
            } else if (itemId == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
            } else if (itemId == R.id.nav_change_password) {
                startActivity(new Intent(this, DangNhap.class));
            }

            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        getTruyen();
        ActionViewFlipper();
    }

    private void AnhXa() {
        recyclerViewTruyen = findViewById(R.id.recyclerViewTatCaTruyen);
        bannerFlipper = findViewById(R.id.bannerFlipper);
        mangTruyen = new ArrayList<>();
        recyclerViewTruyen.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerViewTruyen.setHasFixedSize(true);

        // Gán Adapter với listener
        truyenAdapter = new TruyenAdapter(this, mangTruyen, this); // Truyền this làm OnTruyenClickListener
        recyclerViewTruyen.setAdapter(truyenAdapter);
    }

    private void getTruyen() {
        compositeDisposable.add(apiDocTruyen.getTruyen()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        truyenModel -> {
                            Log.d("GetTruyen", "API response received");
                            if (truyenModel.isSuccess()) {
                                mangTruyen.clear();
                                mangTruyen.addAll(truyenModel.getResult());
                                Log.d("GetTruyen", "Số truyện nhận được: " + mangTruyen.size());
                                truyenAdapter.notifyDataSetChanged();
                                Log.d("GetTruyen", "Đã gọi notifyDataSetChanged()");
                            } else {
                                Log.d("GetTruyen", "API thất bại: " + truyenModel.getMessage());
                                Toast.makeText(getApplicationContext(), "Không lấy được dữ liệu: " + truyenModel.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        },
                        throwable -> {
                            Log.e("GetTruyen", "Lỗi khi gọi API: " + throwable.getMessage(), throwable);
                            Toast.makeText(getApplicationContext(), "Lỗi kết nối: " + throwable.toString(), Toast.LENGTH_LONG).show();
                        }
                ));
    }

    private void ActionViewFlipper() {
        List<String> Truyen = new ArrayList<>();
        Truyen.add("https://photo.znews.vn/w860/Uploaded/piqbzcvo/2020_12_28/1.jpg");
        Truyen.add("https://drive.google.com/uc?export=view&id=1Dm_t2fAzwTzWLUjeQCLaDmRFph_dRjuW");
        Truyen.add("https://drive.google.com/uc?export=view&id=14pDP5tb5PxTGDla3r1tphZU3BA4WvF3R");
        for (int i = 0; i < Truyen.size(); i++) {
            Log.d("ViewFlipper", "Đang thêm ảnh: " + Truyen.get(i));
            ImageView imageView = new ImageView(getApplicationContext());
            Glide.with(getApplicationContext()).load(Truyen.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            bannerFlipper.addView(imageView);
        }
        Log.d("ViewFlipper", "Tổng số ảnh trong ViewFlipper: " + bannerFlipper.getChildCount());

        bannerFlipper.setFlipInterval(7000);
        bannerFlipper.setAutoStart(true);
        Animation slide_in = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_right);
        Animation slide_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_out_right);
        bannerFlipper.setInAnimation(slide_in);
        bannerFlipper.setOutAnimation(slide_out);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onTruyenClick(Truyen truyen) {
        Log.d("TruyenClick", "Truyen clicked: " + truyen.getTen());
        Intent intent = new Intent(TrangChuActivity.this, ChiTietTruyen.class);
        intent.putExtra("truyen", truyen);
        startActivity(intent);
    }
}