package com.example.appbtl.admin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import com.example.appbtl.tinhnang.Chapter;
import com.example.appbtl.tinhnang.ChapterAdapter;
import com.example.appbtl.tinhnang.Truyen;
import com.example.appbtl.tinhnang.TruyenAdapter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AdminActivity extends AppCompatActivity implements TruyenAdapter.OnTruyenClickListener {

    private EditText editTruyenTitle, editTruyenDescription, editTruyenAuthor, editChapter;
    private MultiAutoCompleteTextView multiGenre; // Thay Spinner bằng MultiAutoCompleteTextView
    private Button btnAddChapter, btnSaveTruyen, btnCancel, btnChooseImage, btnManageGenre;
    private ImageView previewTruyenImage;
    private RecyclerView chapterRecyclerView, truyenRecyclerView;
    private ChapterAdapter chapterAdapter;
    private TruyenAdapter truyenAdapter;
    private List<Chapter> chapterList;
    private List<Truyen> truyenList;
    private Truyen selectedTruyen = null;
    private Uri selectedImageUri = null;
    private List<String> genreList;

    private final ActivityResultLauncher<String> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    previewTruyenImage.setImageURI(uri);
                }
            }
    );

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_truyen);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Admin - Quản lý truyện");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo các view
        editTruyenTitle = findViewById(R.id.editTruyenTitle);
        editTruyenDescription = findViewById(R.id.editTruyenDescription);
        editTruyenAuthor = findViewById(R.id.editTruyenAuthor);
        multiGenre = findViewById(R.id.multiGenre);
        btnAddChapter = findViewById(R.id.btnAddChapter);
        btnSaveTruyen = findViewById(R.id.btnSaveTruyen);
        btnCancel = findViewById(R.id.btnCancel);
        btnChooseImage = findViewById(R.id.btnChooseImage);
        btnManageGenre = findViewById(R.id.btnManageGenre);
        previewTruyenImage = findViewById(R.id.previewTruyenImage);
        chapterRecyclerView = findViewById(R.id.chapterRecyclerView);
        truyenRecyclerView = findViewById(R.id.truyenRecyclerView);

        // Khởi tạo danh sách thể loại với fake data
        genreList = new ArrayList<>();
        genreList.add("Hành động");
        genreList.add("Phiêu lưu");
        genreList.add("Hài hước");
        genreList.add("Kinh dị");
        genreList.add("Tình cảm");
        genreList.add("Khoa học viễn tưởng");
        genreList.add("Trinh thám");

        // Thiết lập MultiAutoCompleteTextView cho thể loại
        ArrayAdapter<String> genreAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, genreList);
        multiGenre.setAdapter(genreAdapter);
        multiGenre.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer()); // Phân cách bằng dấu phẩy

        // Nhận truyenList từ Intent hoặc tạo dữ liệu giả
        Intent intent = getIntent();
        truyenList = (List<Truyen>) intent.getSerializableExtra("truyenList");
        if (truyenList == null) {
            truyenList = new ArrayList<>();
            List<Chapter> dragonBallChapters = new ArrayList<>();
            dragonBallChapters.add(new Chapter("Chương 1", Arrays.asList("content://media/external/images/media/1001")));
            truyenList.add(new Truyen(1, "Dragon Ball", "drawable://dragon_ball", "Cuộc phiêu lưu của Goku.", "Akira Toriyama", Arrays.asList("Hành động", "Phiêu lưu"), dragonBallChapters));

            List<Chapter> narutoChapters = new ArrayList<>();
            narutoChapters.add(new Chapter("Chương 1", Arrays.asList("content://media/external/images/media/2001")));
            truyenList.add(new Truyen(2, "Naruto", "drawable://naruto", "Hành trình trở thành Hokage.", "Masashi Kishimoto", Arrays.asList("Phiêu lưu", "Hành động"), narutoChapters));

            List<Chapter> onePieceChapters = new ArrayList<>();
            onePieceChapters.add(new Chapter("Chương 1", Arrays.asList("content://media/external/images/media/3001")));
            truyenList.add(new Truyen(3, "One Piece", "drawable://ic_tien_nghich", "Cuộc phiêu lưu của Luffy.", "Eiichiro Oda", Arrays.asList("Phiêu lưu", "Hài hước"), onePieceChapters));
        }

        // Thiết lập RecyclerView cho danh sách truyện
        truyenRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        truyenAdapter = new TruyenAdapter(truyenList, this);
        truyenRecyclerView.setAdapter(truyenAdapter);

        // Thiết lập RecyclerView cho danh sách chương
        chapterList = new ArrayList<>();
        chapterRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chapterAdapter = new ChapterAdapter(chapterList, position -> {
            new AlertDialog.Builder(this)
                    .setTitle("Xác nhận")
                    .setMessage("Bạn có chắc muốn xóa chương này?")
                    .setPositiveButton("Có", (dialog, which) -> {
                        chapterList.remove(position);
                        chapterAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Đã xóa chương", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Không", null)
                    .show();
        });
        chapterRecyclerView.setAdapter(chapterAdapter);

        // Xử lý nút chọn ảnh
        btnChooseImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));

        // Xử lý nút quản lý thể loại
        btnManageGenre.setOnClickListener(v -> {
            Intent genreIntent = new Intent(AdminActivity.this, AdminTheLoai.class);
            startActivityForResult(genreIntent, 1);
        });

        // Xử lý sự kiện lưu truyện
        btnSaveTruyen.setOnClickListener(v -> {
            String title = editTruyenTitle.getText().toString().trim();
            String description = editTruyenDescription.getText().toString().trim();
            String author = editTruyenAuthor.getText().toString().trim();
            String genresInput = multiGenre.getText().toString().trim();
            String imageUrl = selectedImageUri != null ? selectedImageUri.toString() : "";

            if (title.isEmpty() || imageUrl.isEmpty() || description.isEmpty() || author.isEmpty() || genresInput.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin và chọn ảnh", Toast.LENGTH_SHORT).show();
                return;
            }

            // Chuyển chuỗi thể loại thành danh sách
            List<String> genres = Arrays.asList(genresInput.split("\\s*,\\s*"));

            if (selectedTruyen == null) {
                Truyen truyen = new Truyen(truyenList.size() + 1, title, imageUrl, description, author, new ArrayList<>(genres), new ArrayList<>(chapterList));
                truyenList.add(truyen);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("truyenList", (Serializable) truyenList);
                setResult(RESULT_OK, resultIntent);
                Toast.makeText(this, "Đã thêm truyện: " + title, Toast.LENGTH_SHORT).show();
            } else {
                int index = truyenList.indexOf(selectedTruyen);
                Truyen updatedTruyen = new Truyen(selectedTruyen.getId(), title, imageUrl, description, author, new ArrayList<>(genres), new ArrayList<>(chapterList));
                truyenList.set(index, updatedTruyen);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("truyenList", (Serializable) truyenList);
                setResult(RESULT_OK, resultIntent);
                Toast.makeText(this, "Đã cập nhật truyện: " + title, Toast.LENGTH_SHORT).show();
                selectedTruyen = null;
            }

            truyenAdapter.notifyDataSetChanged();
            resetForm();
        });

        // Xử lý sự kiện hủy
        btnCancel.setOnClickListener(v -> resetForm());
    }

    @Override
    public void onTruyenClick(Truyen truyen) {
        new AlertDialog.Builder(this)
                .setTitle("Quản lý truyện")
                .setMessage("Bạn muốn làm gì với truyện: " + truyen.getTitle() + "?")
                .setPositiveButton("Chỉnh sửa", (dialog, which) -> {
                    selectedTruyen = truyen;
                    editTruyenTitle.setText(truyen.getTitle());
                    editTruyenDescription.setText(truyen.getDescription());
                    editTruyenAuthor.setText(truyen.getAuthor());
                    multiGenre.setText(String.join(", ", truyen.getGenres())); // Hiển thị các thể loại
                    chapterList.clear();
                    chapterList.addAll(truyen.getChapters());
                    chapterAdapter.notifyDataSetChanged();
                    selectedImageUri = Uri.parse(truyen.getImageUrl());
                    previewTruyenImage.setImageURI(selectedImageUri);
                    btnSaveTruyen.setText("Cập nhật truyện");
                })
                .setNegativeButton("Xóa", (dialog, which) -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Xác nhận")
                            .setMessage("Bạn có chắc muốn xóa truyện: " + truyen.getTitle() + "?")
                            .setPositiveButton("Có", (d, w) -> {
                                truyenList.remove(truyen);
                                truyenAdapter.notifyDataSetChanged();
                                Toast.makeText(this, "Đã xóa truyện: " + truyen.getTitle(), Toast.LENGTH_SHORT).show();
                                resetForm();
                            })
                            .setNegativeButton("Không", null)
                            .show();
                })
                .setNeutralButton("Hủy", null)
                .show();
    }

    private void resetForm() {
        editTruyenTitle.setText("");
        editTruyenDescription.setText("");
        editTruyenAuthor.setText("");
        multiGenre.setText("");
        chapterList.clear();
        chapterAdapter.notifyDataSetChanged();
        previewTruyenImage.setImageResource(android.R.color.transparent);
        selectedImageUri = null;
        btnSaveTruyen.setText("Lưu truyện");
        selectedTruyen = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Cập nhật danh sách thể loại nếu GenreActivity trả về dữ liệu
            genreList = data.getStringArrayListExtra("genreList");
            if (genreList != null) {
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, genreList);
                multiGenre.setAdapter(adapter);
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}