package com.example.appbtl.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;

import java.util.ArrayList;
import java.util.List;

public class AdminTheLoai extends AppCompatActivity {

    private EditText editGenre;
    private Button btnAddGenre;
    private RecyclerView genreRecyclerView;
    private GenreAdapter TheLoaiAdapter;
    private List<String> genreList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_theloai);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Quản lý thể loại");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo các view
        editGenre = findViewById(R.id.editGenre);
        btnAddGenre = findViewById(R.id.btnAddGenre);
        genreRecyclerView = findViewById(R.id.genreRecyclerView);

        // Khởi tạo danh sách thể loại với fake data
        genreList = new ArrayList<>();
        genreList.add("Hành động");
        genreList.add("Phiêu lưu");
        genreList.add("Hài hước");
        genreList.add("Kinh dị");
        genreList.add("Tình cảm");
        genreList.add("Khoa học viễn tưởng");
        genreList.add("Trinh thám");

        // Thiết lập RecyclerView
        genreRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        TheLoaiAdapter = new GenreAdapter(genreList);
        genreRecyclerView.setAdapter(TheLoaiAdapter);

        // Xử lý sự kiện thêm thể loại
        btnAddGenre.setOnClickListener(v -> {
            String genre = editGenre.getText().toString().trim();
            if (!genre.isEmpty()) {
                if (!genreList.contains(genre)) {
                    genreList.add(genre);
                    TheLoaiAdapter.notifyDataSetChanged();
                    editGenre.setText("");
                    Toast.makeText(this, "Đã thêm thể loại: " + genre, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Thể loại đã tồn tại", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Vui lòng nhập tên thể loại", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent resultIntent = new Intent();
        resultIntent.putStringArrayListExtra("genreList", new ArrayList<>(genreList));
        setResult(RESULT_OK, resultIntent);
        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private class GenreAdapter extends RecyclerView.Adapter<GenreAdapter.GenreViewHolder> {
        private List<String> genres;

        public GenreAdapter(List<String> genres) {
            this.genres = genres;
        }

        @NonNull
        @Override
        public GenreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Thay simple_list_item_1 bằng layout tùy chỉnh
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_genre, parent, false);
            return new GenreViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull GenreViewHolder holder, int position) {
            String genre = genres.get(position);
            holder.genreText.setText(genre);
            holder.itemView.setOnLongClickListener(v -> {
                Log.d("AdminTheLoai", "Long click on: " + genre); // Debug để kiểm tra
                new AlertDialog.Builder(AdminTheLoai.this)
                        .setTitle("Xác nhận")
                        .setMessage("Bạn có chắc muốn xóa thể loại: " + genre + "?")
                        .setPositiveButton("Có", (dialog, which) -> {
                            genres.remove(position);
                            notifyDataSetChanged();
                            Toast.makeText(AdminTheLoai.this, "Đã xóa thể loại: " + genre, Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Không", null)
                        .show();
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return genres.size();
        }

        class GenreViewHolder extends RecyclerView.ViewHolder {
            TextView genreText;

            GenreViewHolder(@NonNull View itemView) {
                super(itemView);
                genreText = itemView.findViewById(R.id.genreText); // ID mới trong layout tùy chỉnh
            }
        }
    }
}