package com.example.appbtl.admin;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import com.example.appbtl.tinhnangnguoidung.BinhLuan;
import java.util.ArrayList;
import java.util.List;

public class AdminBinhLuan extends AppCompatActivity {

    private RecyclerView commentAdminRecyclerView;
    private CommentAdminAdapter commentAdapter;
    private List<BinhLuan> commentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_binhluan);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Quản lý bình luận");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        commentAdminRecyclerView = findViewById(R.id.commentAdminRecyclerView);

        // Khởi tạo fake data
        commentList = new ArrayList<>();
        commentList.add(new BinhLuan("Nguyen Van A", "Hay quá"));
        commentList.add(new BinhLuan("Tran Thi B", "Đẹp quá"));
        commentList.add(new BinhLuan("User", "Tuyệt vời"));

        // Thiết lập RecyclerView
        commentAdminRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        commentAdapter = new CommentAdminAdapter(commentList);
        commentAdminRecyclerView.setAdapter(commentAdapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adapter nội bộ cho RecyclerView
    private class CommentAdminAdapter extends RecyclerView.Adapter<CommentAdminAdapter.CommentViewHolder> {

        private List<BinhLuan> comments;

        public CommentAdminAdapter(List<BinhLuan> comments) {
            this.comments = comments;
        }

        @Override
        public CommentViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_comment_admin, parent, false);
            return new CommentViewHolder(view);
        }

        @Override
        public void onBindViewHolder(CommentViewHolder holder, int position) {
            BinhLuan comment = comments.get(position);
            holder.name.setText(comment.getName());
            holder.content.setText(comment.getContent());

            // Xử lý sự kiện nhấn giữ để xóa
            holder.itemView.setOnLongClickListener(v -> {
                new AlertDialog.Builder(AdminBinhLuan.this)
                        .setTitle("Xác nhận")
                        .setMessage("Bạn có chắc muốn xóa bình luận: \"" + comment.getContent() + "\" của " + comment.getName() + "?")
                        .setPositiveButton("Có", (dialog, which) -> {
                            comments.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, comments.size());
                            Toast.makeText(AdminBinhLuan.this, "Đã xóa bình luận", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Không", null)
                        .show();
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return comments != null ? comments.size() : 0;
        }

        class CommentViewHolder extends RecyclerView.ViewHolder {
            TextView name, content;

            public CommentViewHolder(View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.commentName);
                content = itemView.findViewById(R.id.commentContent);
            }
        }
    }
}