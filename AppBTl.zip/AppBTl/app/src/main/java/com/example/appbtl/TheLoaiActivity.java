package com.example.appbtl;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import com.example.appbtl.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TheLoaiActivity extends AppCompatActivity {

    private ListView listViewTheLoai;
    private Spinner spinnerTheLoai;
    private SearchView searchView;
    private TruyenAdapter truyenAdapter;
    private List<Truyen> truyenList; // Danh sách truyện với ảnh
    private List<String> theLoaiList; // Danh sách thể loại

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.the_loai);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Thể loại");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo view
        listViewTheLoai = findViewById(R.id.listViewTheLoai);
        spinnerTheLoai = findViewById(R.id.spinnerTheLoai);
        searchView = findViewById(R.id.searchView);

        // Fake data cho truyện và thể loại
        truyenList = new ArrayList<>(Arrays.asList(
                new Truyen("Dragon Ball", "Hành động", String.valueOf(R.drawable.ic_tien_nghich)),
                new Truyen("Naruto", "Hành động", String.valueOf(R.drawable.ic_tien_nghich)),
                new Truyen("One Piece", "Phiêu lưu", String.valueOf(R.drawable.ic_tien_nghich)),
                new Truyen("Doraemon", "Hài hước", String.valueOf(R.drawable.ic_launcher_background)),
                new Truyen("Demon Slayer", "Kinh dị", String.valueOf(R.drawable.ic_launcher_background))
        ));
        theLoaiList = new ArrayList<>(Arrays.asList(
                "Tất cả", "Hành động", "Phiêu lưu", "Hài hước", "Kinh dị"
        ));

        // Thiết lập adapter cho ListView
        truyenAdapter = new TruyenAdapter(truyenList);
        listViewTheLoai.setAdapter(truyenAdapter);

        // Thiết lập adapter cho Spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, theLoaiList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTheLoai.setAdapter(spinnerAdapter);

        // Xử lý sự kiện chọn thể loại trong Spinner
        spinnerTheLoai.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedTheLoai = theLoaiList.get(position);
                filterTruyen(selectedTheLoai, searchView.getQuery().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Không làm gì
            }
        });

        // Xử lý sự kiện tìm kiếm trong SearchView
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterTruyen(spinnerTheLoai.getSelectedItem().toString(), newText);
                return true;
            }
        });
    }

    // Hàm lọc truyện theo thể loại và từ khóa tìm kiếm
    private void filterTruyen(String theLoai, String query) {
        List<Truyen> filteredList = new ArrayList<>();
        for (Truyen truyen : truyenList) {
            boolean matchesTheLoai = theLoai.equals("Tất cả") || truyen.theLoai.equals(theLoai);
            boolean matchesQuery = query.isEmpty() || truyen.title.toLowerCase().contains(query.toLowerCase());
            if (matchesTheLoai && matchesQuery) {
                filteredList.add(truyen);
            }
        }
        truyenAdapter.updateList(filteredList);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Lớp Truyen để lưu thông tin truyện
    private static class Truyen {
        String title;
        String theLoai;
        String imageUrl;

        Truyen(String title, String theLoai, String imageUrl) {
            this.title = title;
            this.theLoai = theLoai;
            this.imageUrl = imageUrl;
        }
    }

    // Custom Adapter cho ListView
    private class TruyenAdapter extends ArrayAdapter<Truyen> {
        private List<Truyen> currentList;

        public TruyenAdapter(List<Truyen> truyenList) {
            super(TheLoaiActivity.this, 0, truyenList);
            this.currentList = new ArrayList<>(truyenList);
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_truyen_the_loai, parent, false);
            }

            Truyen truyen = currentList.get(position);
            ImageView imageView = convertView.findViewById(R.id.truyenImage);
            TextView textView = convertView.findViewById(R.id.truyenTitle);

            textView.setText(truyen.title);
            try {
                imageView.setImageURI(android.net.Uri.parse(truyen.imageUrl));
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.ic_launcher_background);
            }

            return convertView;
        }

        public void updateList(List<Truyen> newList) {
            currentList.clear();
            currentList.addAll(newList);
            notifyDataSetChanged();
        }
    }
}