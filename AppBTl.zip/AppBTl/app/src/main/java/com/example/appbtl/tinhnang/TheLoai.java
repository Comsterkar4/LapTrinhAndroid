package com.example.appbtl.tinhnang;

import java.io.Serializable;

public class TheLoai implements Serializable {
    private String name;

    // Constructor
    public TheLoai(String name) {
        this.name = name;
    }

    // Getter
    public String getName() {
        return name;
    }

    // Setter
    public void setName(String name) {
        this.name = name;
    }
}