package com.example.appbtl.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import com.example.appbtl.tinhnang.Chapter;
import com.example.appbtl.tinhnang.Truyen;

import java.util.ArrayList;
import java.util.List;

public class AdminChap extends AppCompatActivity {

    private RecyclerView truyenRecyclerView;
    private TruyenAdapter truyenAdapter;
    private List<Truyen> truyenList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.admin_chap);

            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                setSupportActionBar(toolbar);
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle("Quản lý chương");
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                }
            } else {
                Log.e("AdminChap", "Toolbar not found in layout");
            }

            truyenRecyclerView = findViewById(R.id.truyenRecyclerView);
            if (truyenRecyclerView == null) {
                Log.e("AdminChap", "truyenRecyclerView not found in layout");
                Toast.makeText(this, "Lỗi giao diện", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // Nhận dữ liệu từ Intent
            Intent intent = getIntent();
            try {
                truyenList = (List<Truyen>) intent.getSerializableExtra("truyenList");
            } catch (Exception e) {
                Log.e("AdminChap", "Error getting truyenList from Intent: " + e.getMessage());
                truyenList = null;
            }

            // Khởi tạo fake data nếu không nhận được từ Intent
            if (truyenList == null) {
                truyenList = new ArrayList<>();
                List<Chapter> emptyChapters = new ArrayList<>();
                truyenList.add(new Truyen(1, "Dragon Ball", String.valueOf(R.drawable.naruto_banner), "", "", new ArrayList<>(), emptyChapters));
                truyenList.add(new Truyen(2, "Naruto", String.valueOf(R.drawable.naruto_banner), "", "", new ArrayList<>(), emptyChapters));
                truyenList.add(new Truyen(3, "One Piece", String.valueOf(R.drawable.naruto_banner), "", "", new ArrayList<>(), emptyChapters));
                truyenList.add(new Truyen(4, "Doraemon", String.valueOf(R.drawable.naruto_banner), "", "", new ArrayList<>(), emptyChapters));
                truyenList.add(new Truyen(5, "Demon Slayer", String.valueOf(R.drawable.naruto_banner), "", "", new ArrayList<>(), emptyChapters));
                Log.d("AdminChap", "Initialized fake data for truyenList");
            }

            // Thiết lập RecyclerView chỉ để hiển thị ảnh và tên
            truyenRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            truyenAdapter = new TruyenAdapter(truyenList);
            truyenRecyclerView.setAdapter(truyenAdapter);

        } catch (Exception e) {
            Log.e("AdminChap", "Error in onCreate: " + e.getMessage());
            Toast.makeText(this, "Lỗi: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adapter cho danh sách truyện
    private class TruyenAdapter extends RecyclerView.Adapter<TruyenAdapter.TruyenViewHolder> {
        private List<Truyen> truyenList;

        public TruyenAdapter(List<Truyen> truyenList) {
            this.truyenList = truyenList;
        }

        @NonNull
        @Override
        public TruyenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_truyen_admin_chap, parent, false);
            return new TruyenViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull TruyenViewHolder holder, int position) {
            Truyen truyen = truyenList.get(position);
            holder.truyenTitle.setText(truyen.getTitle());
            try {
                if (truyen.getImageUrl() != null && !truyen.getImageUrl().isEmpty()) {
                    holder.truyenImage.setImageURI(android.net.Uri.parse(truyen.getImageUrl()));
                } else {
                    holder.truyenImage.setImageResource(R.drawable.ic_launcher_background);
                }
            } catch (Exception e) {
                Log.e("AdminChap", "Error loading image for " + truyen.getTitle() + ": " + e.getMessage());
                holder.truyenImage.setImageResource(R.drawable.ic_launcher_background);
            }
            // Khi nhấn vào truyện, mở AddChapterActivity
            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(AdminChap.this, AddChapterActivity.class);
                intent.putExtra("truyen", truyen);
                startActivity(intent); // Chỉ mở, không cần trả kết quả
            });
        }

        @Override
        public int getItemCount() {
            return truyenList.size();
        }

        class TruyenViewHolder extends RecyclerView.ViewHolder {
            ImageView truyenImage;
            TextView truyenTitle;

            TruyenViewHolder(@NonNull View itemView) {
                super(itemView);
                truyenImage = itemView.findViewById(R.id.truyenImage);
                truyenTitle = itemView.findViewById(R.id.truyenTitle);
            }
        }
    }
}