package com.example.appbtl.admin;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import com.example.appbtl.tinhnang.Chapter;

import java.util.ArrayList;
import java.util.List;

public class AdminAddAnhChapter extends AppCompatActivity {

    private Button btnAddImage, btnSave, btnCancel;
    private RecyclerView imageRecyclerView;
    private ImageAdapter imageAdapter;
    private List<String> imageUris; // Danh sách URI ảnh của chương
    private Chapter chapter;
    private int position;

    private final ActivityResultLauncher<String> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    imageUris.add(uri.toString());
                    imageAdapter.notifyDataSetChanged();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_anh_chapter);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Thêm ảnh cho chương");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        btnAddImage = findViewById(R.id.btnAddImage);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);
        imageRecyclerView = findViewById(R.id.imageRecyclerView);

        // Nhận dữ liệu từ Intent
        Intent intent = getIntent();
        chapter = (Chapter) intent.getSerializableExtra("chapter");
        position = intent.getIntExtra("position", -1);
        if (chapter == null || position == -1) {
            Toast.makeText(this, "Không nhận được dữ liệu chương", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Khởi tạo danh sách ảnh từ chapter
        imageUris = new ArrayList<>(chapter.getContent());

        // Thiết lập RecyclerView cho danh sách ảnh
        imageRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        imageAdapter = new ImageAdapter(imageUris);
        imageRecyclerView.setAdapter(imageAdapter);

        // Xử lý nút thêm ảnh
        btnAddImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));

        // Xử lý nút lưu
        btnSave.setOnClickListener(v -> {
            chapter = new Chapter(chapter.getChapterNumber(), imageUris);
            Intent resultIntent = new Intent();
            resultIntent.putExtra("updated_chapter", chapter);
            resultIntent.putExtra("position", position);
            setResult(RESULT_OK, resultIntent);
            finish();
        });

        // Xử lý nút hủy
        btnCancel.setOnClickListener(v -> finish());
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adapter cho danh sách ảnh
    private static class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {
        private List<String> imageUris;

        public ImageAdapter(List<String> imageUris) {
            this.imageUris = imageUris;
        }

        @NonNull
        @Override
        public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ImageView imageView = new ImageView(parent.getContext());
            imageView.setLayoutParams(new RecyclerView.LayoutParams(100, 100));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            return new ImageViewHolder(imageView);
        }

        @Override
        public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
            holder.imageView.setImageURI(Uri.parse(imageUris.get(position)));
        }

        @Override
        public int getItemCount() {
            return imageUris.size();
        }

        static class ImageViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;

            ImageViewHolder(@NonNull ImageView itemView) {
                super(itemView);
                imageView = itemView;
            }
        }
    }
}