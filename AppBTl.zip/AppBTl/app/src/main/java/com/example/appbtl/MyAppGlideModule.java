package com.example.appbtl;

import android.content.Context;
import com.bumptech.glide.Glide;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.module.AppGlideModule;
import okhttp3.OkHttpClient;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

@GlideModule
public class MyAppGlideModule extends AppGlideModule {
    @Override
    public void registerComponents(Context context, Glide glide, Registry registry) {
        // Tạo OkHttpClient với timeout tùy chỉnh
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS) // Timeout kết nối: 10 giây
                .readTimeout(10, TimeUnit.SECONDS)    // Timeout đọc dữ liệu: 10 giây
                .writeTimeout(10, TimeUnit.SECONDS)   // Timeout ghi dữ liệu: 10 giây
                .build();

        // Thay thế HttpUrlFetcher mặc định bằng OkHttpUrlLoader
        OkHttpUrlLoader.Factory factory = new OkHttpUrlLoader.Factory(client);
        registry.replace(GlideUrl.class, InputStream.class, factory);
    }
}
