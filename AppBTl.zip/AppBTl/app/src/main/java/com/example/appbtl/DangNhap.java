package com.example.appbtl;
import io.paperdb.Paper;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.appbtl.admin.AdminActivity;
import com.example.appbtl.admin.GiaoDienAdmin;
import com.example.appbtl.model.UserModel;
import com.example.appbtl.retrofit.ApiDocTruyen;
import com.example.appbtl.retrofit.RetrofitClient;
import com.example.appbtl.utils.Utils;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;


public class DangNhap extends AppCompatActivity {

    private EditText edtEmail, edtPassword;
    private Button btnLogin;
    private TextView tvLogin;
    ApiDocTruyen apiDocTruyen;
    CompositeDisposable compositeDisposable = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dang_nhap);

        if(isConnected(this)){
            Toast.makeText(getApplicationContext(), "ok",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(),"khong co internet",Toast.LENGTH_SHORT).show();
        }

        initView();
        initControll();

    }
    private  void initControll(){
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DangNhap.this, DangKy.class);
                startActivity(intent);
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String str_email = edtEmail.getText().toString().trim();
              String str_pass = edtPassword.getText().toString().trim();
                if(TextUtils.isEmpty(str_email)){
                    Toast.makeText(getApplicationContext(), "Bạn chưa nhập Email", Toast.LENGTH_SHORT).show();
                }else if(TextUtils.isEmpty(str_pass)){
                    Toast.makeText(getApplicationContext(), "Bạn chưa nhập Mật khẩu", Toast.LENGTH_SHORT).show();
                }else{
                    Paper.book().write("email", str_email);
                    Paper.book().write("pass", str_pass);
                    compositeDisposable.add(apiDocTruyen.dangNhap(str_email,str_pass)
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(
                                   userModel -> {
                                       if(userModel.isSuccess()){
                                           Utils.user_current = userModel.getResult().get(0);
                                           Intent intent = new Intent(getApplicationContext(), TrangChuActivity.class);
                                           startActivity(intent);
                                           finish();
                                       }
                                   },
                                   throwable ->{
                                       Toast.makeText(getApplicationContext(), throwable.getMessage(),Toast.LENGTH_SHORT).show();
                                   }
                            ));
                }
            }
        });
    }
    private void initView() {
        Paper.init(this);
        apiDocTruyen = RetrofitClient.getInstance(Utils.BASE_URL).create(ApiDocTruyen.class);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvLogin = findViewById(R.id.tvLogin);
        if(Paper.book().read("email") != null && Paper.book().read("pass") != null ){
            edtEmail.setText(Paper.book().read("email"));
            edtPassword.setText(Paper.book().read("pass"));
        }
    }


    private boolean isConnected(Context context){
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI); //nho them quyen vao khong bi loi
        NetworkInfo mobile = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if((wifi != null && wifi.isConnected())|| (mobile != null && mobile.isConnected())){
            return true;
        }else{
            return false;
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if( Utils.user_current.getEmail() != null && Utils.user_current.getPass() != null){
            edtEmail.setText(Utils.user_current.getEmail());
            edtPassword.setText(Utils.user_current.getPass());
        }
    }

    @Override
    protected void onDestroy() {
        compositeDisposable.clear();
        super.onDestroy();
    }
}