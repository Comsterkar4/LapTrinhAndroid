package com.example.appbtl;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.tinhnang.ChapterAdapter;
import com.example.appbtl.tinhnang.Truyen;
import com.example.appbtl.tinhnangnguoidung.BinhLuan;
import com.example.appbtl.tinhnangnguoidung.BinhLuanAdapter;

import java.util.ArrayList;
import java.util.List;

public class ChiTietTruyen extends AppCompatActivity {

    private ImageView truyenImage;
    private TextView truyenTitle, truyenDescription, truyenAuthor, truyenGenre;
    private RecyclerView chapterRecyclerView, commentRecyclerView;
    private ChapterAdapter chapterAdapter;
    private BinhLuanAdapter binhLuanAdapter;
    private EditText commentInput;
    private Button commentButton;
    private List<BinhLuan> commentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chi_tiet_truyen);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Chi tiết truyện");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        truyenImage = findViewById(R.id.truyenImage);
        truyenTitle = findViewById(R.id.truyenTitle);
        truyenDescription = findViewById(R.id.truyenDescription);
        truyenAuthor = findViewById(R.id.truyenAuthor);
        truyenGenre = findViewById(R.id.truyenGenre);
        chapterRecyclerView = findViewById(R.id.chapterRecyclerView);
        commentRecyclerView = findViewById(R.id.commentRecyclerView);
        commentInput = findViewById(R.id.commentInput);
        commentButton = findViewById(R.id.commentButton);

        if (chapterRecyclerView == null || commentRecyclerView == null) {
            throw new IllegalStateException("RecyclerView not found in layout");
        }

        // Khởi tạo danh sách bình luận với fake data
        commentList = new ArrayList<>();
        commentList.add(new BinhLuan("Nguyen Van A", "Hay quá"));
        commentList.add(new BinhLuan("Tran Thi B", "Đẹp quá"));

        Truyen truyen = (Truyen) getIntent().getSerializableExtra("truyen");
        if (truyen != null) {
            truyenTitle.setText(truyen.getTitle() != null && !truyen.getTitle().isEmpty() ? truyen.getTitle() : "Không có tiêu đề");
            truyenDescription.setText(truyen.getDescription() != null && !truyen.getDescription().isEmpty() ? truyen.getDescription() : "Không có mô tả");
            truyenAuthor.setText(truyen.getAuthor() != null && !truyen.getAuthor().isEmpty() ? "Tác giả: " + truyen.getAuthor() : "Tác giả: Không rõ");
            truyenGenre.setText(truyen.getGenres() != null && !truyen.getGenres().isEmpty() ? "Thể loại: " + String.join(", ", truyen.getGenres()) : "Thể loại: Không rõ");

            String imageUrl = truyen.getImageUrl();
            if (imageUrl != null && !imageUrl.isEmpty()) {
                truyenImage.setImageURI(Uri.parse(imageUrl));
            } else {
                truyenImage.setImageResource(R.drawable.ic_tien_nghich);
            }

            if (truyen.getChapters() != null && !truyen.getChapters().isEmpty()) {
                chapterRecyclerView.setLayoutManager(new LinearLayoutManager(this));
                chapterAdapter = new ChapterAdapter(truyen.getChapters());
                chapterRecyclerView.setAdapter(chapterAdapter);
            } else {
                chapterRecyclerView.setVisibility(RecyclerView.GONE);
            }

            // Thiết lập RecyclerView cho bình luận
            commentRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            binhLuanAdapter = new BinhLuanAdapter(commentList);
            commentRecyclerView.setAdapter(binhLuanAdapter);

            // Xử lý sự kiện nhấn nút "Bình luận"
            commentButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String newComment = commentInput.getText().toString().trim();
                    if (!newComment.isEmpty()) {
                        // Giả sử tên người dùng là "User" khi thêm bình luận mới
                        commentList.add(0, new BinhLuan("User", newComment));
                        binhLuanAdapter.notifyItemInserted(0);
                        commentRecyclerView.scrollToPosition(0);
                        commentInput.setText("");
                        if (commentRecyclerView.getVisibility() == RecyclerView.GONE) {
                            commentRecyclerView.setVisibility(RecyclerView.VISIBLE);
                        }
                    }
                }
            });
        } else {
            truyenTitle.setText("Không có tiêu đề");
            truyenDescription.setText("Không có mô tả");
            truyenAuthor.setText("Tác giả: Không rõ");
            truyenGenre.setText("Thể loại: Không rõ");
            truyenImage.setImageResource(R.drawable.ic_tien_nghich);
            chapterRecyclerView.setVisibility(RecyclerView.GONE);
            commentRecyclerView.setVisibility(RecyclerView.GONE);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}