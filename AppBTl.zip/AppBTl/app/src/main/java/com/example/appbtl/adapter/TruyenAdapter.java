package com.example.appbtl.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.appbtl.R;
import com.example.appbtl.model.Truyen;

import java.util.List;

public class TruyenAdapter extends RecyclerView.Adapter<TruyenAdapter.MyViewHolder> {
   Context context;
   List<Truyen> array;
    private OnTruyenClickListener listener;

    public TruyenAdapter(Context context, List<Truyen> array,  OnTruyenClickListener listener) {
        this.context = context;
        this.array = array;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_truyen,parent,false);
        return new MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
      Truyen truyen= array.get(position);
      holder.tentruyen.setText(truyen.getTen());
        Glide.with(context).load(truyen.getAnh_bia()).into(holder.anhtruyen);
    }

    @Override
    public int getItemCount() {
        Log.d("DEBUG", "Số lượng truyện trong adapter: " + array.size());
        return array.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
       TextView tentruyen;
       ImageView anhtruyen;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tentruyen = itemView.findViewById(R.id.truyenTitle);
            anhtruyen = itemView.findViewById(R.id.truyenImage);
        }
    }
    public interface OnTruyenClickListener {
        void onTruyenClick(com.example.appbtl.model.Truyen truyen);
    }
}
