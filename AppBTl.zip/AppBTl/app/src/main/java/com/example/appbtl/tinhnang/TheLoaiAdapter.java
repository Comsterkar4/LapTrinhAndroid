package com.example.appbtl.tinhnang;

public class TheLoaiAdapter
{
}
