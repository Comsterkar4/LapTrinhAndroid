package com.example.appbtl.admin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import com.example.appbtl.tinhnang.Chapter;
import com.example.appbtl.tinhnang.ChapterAdapter;
import com.example.appbtl.tinhnang.Truyen;

import java.util.ArrayList;
import java.util.List;

public class AddChapterActivity extends AppCompatActivity {

    private EditText editChapterNumber;
    private Button btnAddChapter, btnSave, btnCancel;
    private RecyclerView chapterRecyclerView;
    private ChapterAdapter chapterAdapter;
    private List<Chapter> chapterList;
    private Truyen truyen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_chapter);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Thêm chương");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo view
        editChapterNumber = findViewById(R.id.editChapterNumber);
        btnAddChapter = findViewById(R.id.btnAddChapter);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);
        chapterRecyclerView = findViewById(R.id.chapterRecyclerView);

        // Nhận truyện từ Intent
        Intent intent = getIntent();
        truyen = (Truyen) intent.getSerializableExtra("truyen");
        if (truyen == null) {
            Toast.makeText(this, "Không nhận được dữ liệu truyện", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        chapterList = new ArrayList<>(truyen.getChapters());

        // Thiết lập RecyclerView cho danh sách chương
        chapterRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chapterAdapter = new ChapterAdapter(chapterList, position -> {
            new AlertDialog.Builder(this)
                    .setTitle("Xác nhận")
                    .setMessage("Bạn có chắc muốn xóa chương này?")
                    .setPositiveButton("Có", (dialog, which) -> {
                        chapterList.remove(position);
                        chapterAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Đã xóa chương", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Không", null)
                    .show();
        }) {
            @Override
            public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {
                super.onBindViewHolder(holder, position);
                holder.itemView.setOnClickListener(v -> {
                    Intent addImageIntent = new Intent(AddChapterActivity.this, AdminAddAnhChapter.class);
                    addImageIntent.putExtra("chapter", chapterList.get(position));
                    addImageIntent.putExtra("position", position);
                    startActivityForResult(addImageIntent, 2);
                });
            }
        };
        chapterRecyclerView.setAdapter(chapterAdapter);

        // Xử lý nút thêm chương (không thêm ảnh)
        btnAddChapter.setOnClickListener(v -> {
            String chapterNumber = editChapterNumber.getText().toString().trim();
            if (chapterNumber.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập số chương", Toast.LENGTH_SHORT).show();
                return;
            }
            Chapter newChapter = new Chapter(chapterNumber, new ArrayList<>());
            chapterList.add(newChapter);
            chapterAdapter.notifyDataSetChanged();
            editChapterNumber.setText("");
            Toast.makeText(this, "Đã thêm chương: " + chapterNumber, Toast.LENGTH_SHORT).show();
        });

        // Xử lý nút lưu
        btnSave.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            truyen = new Truyen(truyen.getId(), truyen.getTitle(), truyen.getImageUrl(),
                    truyen.getDescription(), truyen.getAuthor(), truyen.getGenres(), chapterList);
            resultIntent.putExtra("updated_truyen", truyen);
            setResult(RESULT_OK, resultIntent);
            finish();
        });

        // Xử lý nút hủy
        btnCancel.setOnClickListener(v -> finish());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            Chapter updatedChapter = (Chapter) data.getSerializableExtra("updated_chapter");
            int position = data.getIntExtra("position", -1);
            if (position != -1 && updatedChapter != null) {
                chapterList.set(position, updatedChapter);
                chapterAdapter.notifyItemChanged(position);
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}