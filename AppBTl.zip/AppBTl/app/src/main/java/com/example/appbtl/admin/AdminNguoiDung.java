package com.example.appbtl.admin;

import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import com.example.appbtl.tinhnangnguoidung.User;
import com.example.appbtl.tinhnangnguoidung.UserAdapter;

import java.util.ArrayList;
import java.util.List;

public class AdminNguoiDung extends AppCompatActivity {

    private RecyclerView userRecyclerView;
    private UserAdapter userAdapter;
    private List<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_nguoidung);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Quản lý người dùng");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo các view
        userRecyclerView = findViewById(R.id.userRecyclerView);
        if (userRecyclerView == null) {
            Toast.makeText(this, "Lỗi giao diện", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Tạo fake data cho danh sách người dùng
        userList = new ArrayList<>();
        userList.add(new User(1, "Nguyen Van A", "nguyenvana@example.com"));
        userList.add(new User(2, "Tran Thi B", "tranthib@example.com"));
        userList.add(new User(3, "Le Van C", "levanc@example.com"));
        userList.add(new User(4, "Pham Thi D", "phamthid@example.com"));
        userList.add(new User(5, "Hoang Van E", "hoangvane@example.com"));

        // Thiết lập RecyclerView cho danh sách người dùng
        userRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        userAdapter = new UserAdapter(userList);
        userRecyclerView.setAdapter(userAdapter);

        // Xử lý sự kiện nhấn giữ để xóa người dùng
        userAdapter.setOnLongClickListener(position -> {
            Toast.makeText(AdminNguoiDung.this, "Đã xóa: " + userList.get(position).getName(), Toast.LENGTH_SHORT).show();
            userList.remove(position);
            userAdapter.notifyDataSetChanged();
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}