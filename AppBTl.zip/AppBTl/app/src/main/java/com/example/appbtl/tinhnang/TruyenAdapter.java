package com.example.appbtl.tinhnang;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appbtl.R;
import java.util.List;

public class TruyenAdapter extends RecyclerView.Adapter<TruyenAdapter.TruyenViewHolder> {

    private List<Truyen> truyenList;
    private OnTruyenClickListener listener;

    public TruyenAdapter(List<Truyen> truyenList, OnTruyenClickListener listener) {
        this.truyenList = truyenList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TruyenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_truyen, parent, false);
        return new TruyenViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TruyenViewHolder holder, int position) {
        Truyen truyen = truyenList.get(position);
        String title = truyen.getTitle();
        List<String> genres = truyen.getGenres();
        // Chỉ thêm genres nếu danh sách không rỗng
        if (genres != null && !genres.isEmpty()) {
            String genresText = String.join(", ", genres);
            holder.truyenTitle.setText(title + " (" + genresText + ")");
        } else {
            holder.truyenTitle.setText(title); // Không thêm () nếu genres rỗng
        }

        String imageUrl = truyen.getImageUrl();
        if (imageUrl != null && !imageUrl.isEmpty()) {
            holder.truyenImage.setImageURI(Uri.parse(imageUrl));
        } else {
            holder.truyenImage.setImageResource(R.drawable.ic_launcher_background);
        }
        holder.itemView.setOnClickListener(v -> listener.onTruyenClick(truyen));
    }

    @Override
    public int getItemCount() {
        return truyenList.size();
    }

    public static class TruyenViewHolder extends RecyclerView.ViewHolder {
        ImageView truyenImage;
        TextView truyenTitle;

        public TruyenViewHolder(@NonNull View itemView) {
            super(itemView);
            truyenImage = itemView.findViewById(R.id.truyenImage);
            truyenTitle = itemView.findViewById(R.id.truyenTitle);
        }
    }

    public interface OnTruyenClickListener {
        void onTruyenClick(Truyen truyen);
    }
}