package com.example.appbtl.utils;

import com.example.appbtl.model.User;

public class Utils {
    public static final String BASE_URL="http://172.20.10.8/appdoctruyentranh/";
    public static User user_current = new User();
}
