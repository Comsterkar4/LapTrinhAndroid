package com.example.appbtl.tinhnangnguoidung;

import java.io.Serializable;

public class BinhLuan implements Serializable {
    private String name;
    private String content;

    // Constructor cho chỉ tên (hiện tại)
    public BinhLuan(String name) {
        this.name = name;
        this.content = ""; // Mặc định không có nội dung
    }

    // Constructor cho cả tên và nội dung
    public BinhLuan(String name, String content) {
        this.name = name;
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }
}